:orphan:

.. _topics-scrapyd:

=======
Scrapyd
=======

Scrapyd has been moved into a separate project.

Its documentation is now hosted at:

    http://scrapyd.readthedocs.org/en/latest/
